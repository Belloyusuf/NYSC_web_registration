Install Python 
If you're not sure whether Python is installed on your computer, you can verify
this by typing python into the shell. If you see something like the following, then
Python is installed on your computer:

Python 3.8.2 (v3.8.2:7b3ab5921f, Feb 24 2020, 17:52:18)
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license" for more information.


Django 3.0 supports Python 3.6, 3.7, and 3.8. In the examples in this book,
we will use Python 3.8.2. If you're using Linux or macOS, you probably have
Python installed. If you're using Windows, you can download a Python installer
at https://www.python.org/downloads/windows/ .


Installing Django and Running the development server

Django comes with a lightweight web server to run your code quickly, without
needing to spend time configuring a production server. When you run the
Django development server, it keeps checking for changes in your code. It reloads
automatically, freeing you from manually reloading it after code changes. However,
it might not notice some actions, such as adding new files to your project, so you
will have to restart the server manually in these cases.

Start the development server by typing the following command from your project's
root folder:

E.g. If your project_folder is in Desktop then nevigate to Desktop in your command prompt 
write this in your command prompt (CMD)
press windows r to open your CMD 

>> cd Desktop
>> cd project_folder
>> python3 manage.py runserver 
or 
>>  python manage.py runserver

You should see something like this:

Watching for file changes with StatReloader
Performing system checks...
System check identified no issues (0 silenced).
January 01, 2020 - 10:00:00
Django version 3.0, using settings 'mysite.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CONTROL-C.


