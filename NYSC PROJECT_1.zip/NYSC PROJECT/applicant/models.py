from django.db import models
from django.utils import timezone
import random




class Insititution(models.Model):
    """
    An Institution names class
    """
    name = models.CharField(("Insitution"), max_length=50)
    created = models.DateField(auto_now=True, auto_now_add=False)
    updated = models.DateField(auto_now=False, auto_now_add=True)
    

    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ('-name',)
        

class StateOfDeployment(models.Model):
    """
    A class that would take care for State of Deployments
    """
    name = models.CharField(("State of Deployment"), max_length=50)
    date_of_reporting = models.DateField(("Date of Reporting"), auto_now=False, auto_now_add=False)
    in_charge = models.CharField(("Officer in Charge"), max_length=50)
    address = models.TextField(("Address of Orientation Camp"))
    created = models.DateField(auto_now=True, auto_now_add=False)
    updated = models.DateField(auto_now=False, auto_now_add=True)


    def __str__(self):
        return self.name
    


class Batch(models.Model):
    """
    Batches 
    """
    name = models.CharField(("Batch"), max_length=1)   
    created = models.DateField(auto_now=True, auto_now_add=False)
    updated = models.DateField(auto_now=False, auto_now_add=True)

    def __str__(self):
        return self.name
    


class Student(models.Model):
    """
    Student information 
    """
    GENDER_CHOICES = (
        ('Male', 'Male'),
        ('Female', 'Female'),
    )
    
    # Custom Call up Number 
    def call_of_Number():
        reg_number =  random.randint(1, 10000)
        return '{}{}'.format(timezone.now().strftime('%Y'), reg_number)
    
    surname = models.CharField(max_length=15)
    other_name = models.CharField(max_length=15)
    image = models.ImageField(("Image"), upload_to="Student Images", height_field=None, width_field=None, max_length=None)
    batch = models.ForeignKey(Batch, verbose_name=("Batch"), on_delete=models.CASCADE)
    call_up_no = models.CharField(default=call_of_Number, primary_key=True, unique=True, editable=False, max_length=255)
    state_of_origin = models.CharField(max_length=50)
    gender = models.CharField(choices=GENDER_CHOICES , max_length=50)
    insitution = models.ForeignKey(Insititution, verbose_name=("Insititution"), on_delete=models.CASCADE)    
    course = models.CharField(max_length=50)
    state_of_deployment = models.ForeignKey(StateOfDeployment, verbose_name=("State of Deployment"), on_delete=models.CASCADE)
    date_of_graduation = models.DateField(auto_now=False, auto_now_add=False)
    created = models.DateField(auto_now=True, auto_now_add=False)
    """
    A class that would take care for State of Deployments
    """
    name = models.CharField(("State of Deployment"), max_length=50)
    date_of_reporting = models.DateField(("Date of Reporting"), auto_now=False, auto_now_add=False)
    in_charge = models.CharField(("Officer in Charge"), max_length=50)
    address = models.TextField(("Address of Orientation Camp"))
   

    
    def __str__(self):
        return self.surname
    
    class Meta:
        ordering = ('call_up_no',)
    
    