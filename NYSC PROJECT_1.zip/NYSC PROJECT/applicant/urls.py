from django import views
from django.urls import path
from . views import  StudentCreate, StudentList,\
                    StudentUpdate, StudentDetail, \
                    BatchViews, BatchList, InsitituteCreate, InsitituteList
                    
                    
from . import views


urlpatterns = [
    path('', views.dashboard, name="dashboard"),
    path('search/', views.search, name="search"),
    path("create-student/", StudentCreate.as_view(), name="create"),
    path("list-student/", StudentList.as_view(), name="list"),
    path("update/<int:pk>/student/", StudentUpdate.as_view(), name="update"),
    path("detail/<int:pk>/student/", StudentDetail.as_view(), name="detail"),
    path("insititution-create/", InsitituteCreate.as_view(), name="school-create"),
    path("insititution-list/", InsitituteList.as_view(), name="school-list"),
    # path("state-create/", StateOfDeploymentCreate.as_view(), name="state-create"),  
    # path("state-list/", StateOfDeploymentList.as_view(), name="state-list"),    
    path("batch-create/", BatchViews.as_view(), name="batch-create"), 
    path("batch-list/", BatchList.as_view(), name="batch-list"), 
    
]