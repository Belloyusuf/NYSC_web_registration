from django.contrib import admin
from .models import Student, StateOfDeployment, Batch, Insititution


admin.site.register([Student, StateOfDeployment, Batch, Insititution])
