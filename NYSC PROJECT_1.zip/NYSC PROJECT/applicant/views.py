from opcode import stack_effect
from django.shortcuts import render, HttpResponse
from django.urls import reverse_lazy
from .models import Student, StateOfDeployment, Batch, Insititution
from .forms import LoginForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView, DetailView
from django.contrib.messages.views import SuccessMessageMixin


def user_login(request):
    """ user login view """
    if request.methond == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(request,
                                username=cd['username'],
                                password=cd['password']
                            )
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponse('Login sucessfully')
                else:
                    return HttpResponse('Disable')
            else:
                return HttpResponse('Invalid Account')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html')



@login_required
def dashboard(request):
    student = Student.objects.all()
    institute = Insititution.objects.all()
    batch = Batch.objects.all()
    state = StateOfDeployment.objects.all()
    
    context = {
        'student':student,
        'institute':institute,
        'batch':batch,
        'state':state
    }
    return render(request, 'content/dashboard.html', context)



def search(request):
    """ Fuction that cares about searching of a product  """
    q=request.GET['q']
    student = Student.objects.filter(call_up_no__icontains=q)
    data = Student.objects.filter(call_up_no__icontains=q).order_by('-surname')
    return render(request, 'content/search.html', {'data':data,
                                                   'student':student})
    


# Student Views 
class StudentCreate(SuccessMessageMixin, CreateView):
    model = Student
    fields = '__all__'
    template_name = 'content/new_student.html'
    context_object_name = 'form'
    success_url = reverse_lazy('dashboard')
    success_message = 'New student Added successfully'
    
    
class StudentList(ListView):
    model = Student
    template_name = 'content/student_list.html'
    context_object_name = 'student'
    


class StudentDetail(DetailView):
    model = Student
    template_name = 'content/student_detail.html'
    context_object_name = 'student'
    
    

class StudentUpdate(SuccessMessageMixin, UpdateView):
    model = Student
    fields = '__all__'
    template_name = 'content/student_update.html'
    context_object_name = 'form'
    success_url = reverse_lazy('dashboard')
    success_message = 'Student Update successfully'
    

# Batch Views 

class BatchViews(SuccessMessageMixin, CreateView):
    model = Batch
    fields = '__all__'
    template_name = 'content/new_batch.html'
    context_object_name = 'form'
    success_url = reverse_lazy('dashboard')
    success_message = 'New Batch successfully'
    

class BatchList(ListView):
    model = Batch
    template_name = 'content/batch_list.html'
    context_object_name = 'batch'
    
# Insititute Views 

class InsitituteCreate(SuccessMessageMixin, CreateView):
    model = Insititution
    fields = '__all__'
    template_name = 'content/insititute.html'
    context_object_name = 'form'
    success_url = reverse_lazy('dashboard')
    success_message = 'Insititution created successfully'
    
class InsitituteList(ListView):
    model = Insititution
    template_name = 'content/insititute_list.html'
    context_object_name = 'insititution'
    
# State of Deployment 

# class StateOfDeploymentCreate(CreateView):
#     model = StateOfDeployment
#     template_name = 'content/state.html'
#     fields = '__all__'
#     context_object_name = 'form'
#     success_url = reverse_lazy('dashboard')
#     success_message = 'State created successfully'
    

# class StateOfDeploymentList(ListView):
#     model = StateOfDeployment
#     template_name = 'content/state_list.html'
#     context_object_name = 'state'