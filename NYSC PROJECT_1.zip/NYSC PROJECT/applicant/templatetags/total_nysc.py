from django import template
from applicant.models import Student


register = template.Library()
@register.simple_tag
def total_student():
    return Student.objects.all().count()